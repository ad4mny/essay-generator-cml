-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 12, 2021 at 12:02 PM
-- Server version: 8.0.26
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `egdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `essays`
--

CREATE TABLE `essays` (
  `id` int NOT NULL,
  `groupid` int DEFAULT NULL,
  `title` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `essays`
--

INSERT INTO `essays` (`id`, `groupid`, `title`, `type`, `status`, `date`) VALUES
(1, 4, 'test', 2, NULL, '11:53:59 2021-10-19'),
(2, 4, 'A Vacation Invitation', 1, 'Submitted', '11:57:03 2021-10-19'),
(3, 5, 'JOB APPLICATION', 5, 'Submitted', '11:59:11 2021-10-19'),
(5, 4, 'Invitation to a wedding', 1, 'Submitted', '20:09:29 2021-10-23'),
(7, 6, 'My test email again', 1, NULL, '11:59:57 2021-11-04'),
(8, 5, 'MY resume email', 1, 'Submitted', '12:00:34 2021-11-04');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `date`) VALUES
(4, 'Group 15', '18:31:42PM 03-11-2021'),
(5, 'Group 5', '18:52:32PM 03-11-2021'),
(6, 'Group 3', '11:59:09AM 04-11-2021');

-- --------------------------------------------------------

--
-- Table structure for table `outlines`
--

CREATE TABLE `outlines` (
  `id` int NOT NULL,
  `essayid` int NOT NULL,
  `vocabid` int NOT NULL,
  `position` int NOT NULL,
  `paragraph` int DEFAULT NULL,
  `datetime` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `outlines`
--

INSERT INTO `outlines` (`id`, `essayid`, `vocabid`, `position`, `paragraph`, `datetime`) VALUES
(83, 5, 16, 1, 2, '14:38:44PM 02-11-2021'),
(84, 5, 13, 2, 2, '14:38:44PM 02-11-2021'),
(107, 5, 1, 1, 1, '14:50:14PM 02-11-2021'),
(108, 5, 4, 2, 1, '14:50:14PM 02-11-2021'),
(109, 5, 5, 3, 1, '14:50:14PM 02-11-2021'),
(110, 5, 6, 4, 1, '14:50:14PM 02-11-2021'),
(111, 5, 3, 5, 1, '14:50:14PM 02-11-2021'),
(112, 2, 2, 1, 1, '19:13:05PM 03-11-2021'),
(113, 2, 3, 2, 1, '19:13:05PM 03-11-2021'),
(114, 2, 16, 1, 2, '19:13:08PM 03-11-2021'),
(115, 2, 13, 2, 2, '19:13:08PM 03-11-2021'),
(116, 8, 2, 1, 1, '12:00:42PM 04-11-2021'),
(117, 8, 3, 2, 1, '12:00:42PM 04-11-2021'),
(118, 8, 4, 3, 1, '12:00:42PM 04-11-2021'),
(119, 8, 5, 4, 1, '12:00:42PM 04-11-2021'),
(120, 8, 6, 5, 1, '12:00:42PM 04-11-2021'),
(121, 8, 7, 6, 1, '12:00:42PM 04-11-2021'),
(122, 8, 13, 1, 2, '12:00:46PM 04-11-2021'),
(123, 8, 15, 2, 2, '12:00:46PM 04-11-2021'),
(124, 8, 16, 3, 2, '12:00:46PM 04-11-2021');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `fullname` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `groupid` int DEFAULT NULL,
  `date` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `phone`, `password`, `groupid`, `date`) VALUES
(1, 'egcmlapp', 'egcmlapp', '04eb137a0a69ab610e467778b6ef5541', NULL, '18:52:36PM 03-11-2021'),
(10, 'siti noormazliana binti hairil faddli', '0142183198', 'db04eb4b07e0aaf8d1d477ae342bdff9', 5, '18:31:45PM 03-11-2021'),
(11, 'mahmud muda bin salman shah', '0134784172', '0d72420ab952097e1005c3c9690578b3', 6, '11:59:14AM 04-11-2021'),
(12, 'nur sokiah kassim ahmad', '0198272811', 'fd61263302c7d2f682ec08e1202ed76b', 4, '18:31:50PM 03-11-2021'),
(13, 'adam aiman bin zulkornain', '0108884288', '1d7c2923c1684726dc23d2901c4d8157', 4, '19:22:34 2021-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `vocabularies`
--

CREATE TABLE `vocabularies` (
  `id` int NOT NULL,
  `word` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `paragraph` int NOT NULL,
  `type` int NOT NULL,
  `datetime` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vocabularies`
--

INSERT INTO `vocabularies` (`id`, `word`, `paragraph`, `type`, `datetime`) VALUES
(1, 'Friends', 1, 1, NULL),
(2, 'Pleasure', 1, 1, NULL),
(3, 'Yoga', 1, 3, NULL),
(4, 'Cycling', 1, 2, NULL),
(5, 'Surfing', 1, 2, NULL),
(6, 'Working', 1, 2, NULL),
(7, 'Arcade', 1, 1, NULL),
(8, 'Party', 1, 4, NULL),
(9, 'Invite', 2, 1, NULL),
(10, 'Good', 2, 5, NULL),
(11, 'You', 2, 1, NULL),
(12, 'Crossword', 2, 2, NULL),
(13, 'Monopoly', 2, 1, NULL),
(14, 'Above', 2, 3, NULL),
(15, 'Below', 2, 2, NULL),
(16, 'Under', 2, 4, NULL),
(18, 'Test', 2, 1, '01:19:44AM 12/11/2021'),
(19, 'Variable', 2, 5, '01:20:45AM 12/11/2021'),
(20, 'Me', 1, 5, '01:21:09AM 12/11/2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `essays`
--
ALTER TABLE `essays`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`groupid`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outlines`
--
ALTER TABLE `outlines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `essayid` (`essayid`),
  ADD KEY `vocabid` (`vocabid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `groupid` (`groupid`);

--
-- Indexes for table `vocabularies`
--
ALTER TABLE `vocabularies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `essays`
--
ALTER TABLE `essays`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `outlines`
--
ALTER TABLE `outlines`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `vocabularies`
--
ALTER TABLE `vocabularies`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `essays`
--
ALTER TABLE `essays`
  ADD CONSTRAINT `essays_ibfk_1` FOREIGN KEY (`groupid`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `outlines`
--
ALTER TABLE `outlines`
  ADD CONSTRAINT `outlines_ibfk_1` FOREIGN KEY (`essayid`) REFERENCES `essays` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `outlines_ibfk_2` FOREIGN KEY (`vocabid`) REFERENCES `vocabularies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`groupid`) REFERENCES `groups` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
